#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#define TRUE 1
#define FALSE 0

// CALCULE TEMP
void temp(){

    double time_spent = 0.0;

    clock_t begin = clock();


    sleep(3);

    clock_t end = clock();


    time_spent += (double)(end - begin) / CLOCKS_PER_SEC;

    printf("Le temp d'execution est : %f seconds\n", time_spent);

}
// REMPLIRE TABLEAUX
void remplirtableau( int tab[], int nb )

{
    int i ;

    for (i=0 ; i<nb ; i++)
        tab[i] = rand() % 1000;

    for(i=0;i<nb;i++)
        printf("%d\t",tab[i]);
    printf("\n\n");
}
// TRI INSERTION
void triinsertion(int *y,int n){
        int i,p,j;
        int x;

        for(i =1; i < n; i++){
            x = y[i];p = i-1;
            while(y[p] > x && p-- >0){}
            p++;
            for(j = i-1; j >= p; j--){
                y[j+1] = y[j];
            }
            y[p] = x;
        }
        temp();
}

void permuter(int *a, int *b) {
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
}
// TRI SELECTION
void triselection(int *y, int n){
        int i, min, j , tmp;

        for(i =0; i < n -1; i++){
                min = i;
                for(j = i+1; j < n ; j++)
                    if(y[j] < y[min])
                        min = j;
                if(min != i){
                        tmp = y[i];
                        y[i] = y[min];
                        y[min] = tmp;
                }
        }
        temp();
}
// TRI RAPIDE
void trirapid(int tab[], int first, int last) {
    int pivot, i, j;

    if(first < last) {
        pivot = first;
        i = first;
        j = last;
        while (i < j) {
            while(tab[i] <= tab[pivot] && i < last)
                i++;
            while(tab[j] > tab[pivot])
                j--;
            if(i < j) {
                permuter(&tab[i], &tab[j]);
            }
        }
        permuter(&tab[pivot], &tab[j]);
        trirapid(tab, first, j - 1);
        trirapid(tab, j + 1, last);
    }
    temp();
}
// TRI FUSION
void trifusion(int i, int j, int tab[], int tmp[]) {

    if(j <= i){ return;}

    int m = (i + j) / 2;

    trifusion(i, m, tab, tmp);
    trifusion(m + 1, j, tab, tmp);

    int g = i;
    int d = m + 1;
    int c;


    for(c = i; c <= j; c++) {
        if(g == m + 1) {
            tmp[c] = tab[d];
            d++;
        }else if (d == j + 1) {
            tmp[c] = tab[g];
            g++;
        }else if (tab[g] < tab[d]) {
            tmp[c] = tab[g];
            g++;
        }else {
            tmp[c] = tab[d];
            d++;
        }
    }

    for(c = i; c <= j; c++) {
        tab[c] = tmp[c];
    }
    temp();
}

//TRI BULLE
void tribulle(int *y,int x){
    int h =0;int tmp =0;int test =1;

    while(test){
        test = FALSE;
        for(h =0; h < x-1; h++){
            if(y[h] > y[h+1]){
                    tmp = y[h+1];
                    y[h+1] = y[h];y[h] = tmp;
                    test = TRUE;
            }
        }
    }
    temp();
}

int main(){
    int nbentiers;
    int i;
    int num;
        printf("\t\t________________________________\n\n");
        printf("\t|\tProgramme : Algorithmes De Tri\n\n");
        printf("\t|\tTP : Algorithmes et Complexite\n\n");
        printf("\t\t________________________________\n\n");

        printf("Donner la taille du tableaux: ");
        scanf("%d",&nbentiers);

    int tab[nbentiers];
    int tmp[nbentiers];



        printf("\n1. Le tri bulle\n");
        printf("2. Le tri par selection\n");
        printf("3. Le tri par insertion\n");
        printf("4. Le tri Rapide \n");
        printf("5. Le tri Fusion \n\n");


        remplirtableau(tab,nbentiers);


        do{
            printf("\n Choisir un tri: \n\n");
        scanf("%d",&num);
        if((num>5)||(num<1))
            printf("\n(!) Ce numero ne figure pas dans la liste !\n");
        }while((num>5)||(num<1));

        if(num==1)  printf("TRI BULLE \n");tribulle(tab,nbentiers);
        if(num==2)  printf("TRI SELECTION \n");triselection(tab,nbentiers);
        if(num==3)  printf("TRI INSERTION \n");triinsertion(tab,nbentiers);
        if(num==4)  printf("TRI RAPIDE\n");trirapid(tab,0,nbentiers-1);
        if(num==5)  printf("TRI FUSION\n"); trifusion(0,nbentiers-1,tab,tmp);


        printf("\TABLEAU TRIER : ");
        for(i=0;i<nbentiers;i++)
            printf("%3d\t",tab[i]);
        printf("\n\n");
        system("PAUSE");
        return 0;
}
